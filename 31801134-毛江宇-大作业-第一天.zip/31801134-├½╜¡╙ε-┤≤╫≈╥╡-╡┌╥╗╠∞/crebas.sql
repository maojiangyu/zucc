/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2020/7/3 16:59:05                            */
/*==============================================================*/


drop table if exists caipu;

drop table if exists dingdan_xiangqing;

drop table if exists guanliyuanxinxi;

drop table if exists leibie;

drop table if exists manzhe_shangpin_guanlian;

drop table if exists manzhe_xinxi;

drop table if exists peisong_dizhi;

drop table if exists shangpin;

drop table if exists shangpin_caipu_tuijian;

drop table if exists shangpin_pinjia;

drop table if exists shangpincaigou;

drop table if exists shangpindingdan;

drop table if exists shenxian_leibie1;

drop table if exists xianshicuxiao;

drop table if exists yonghuxinxi;

drop table if exists youhuicard;

/*==============================================================*/
/* Table: caipu                                                 */
/*==============================================================*/
create table caipu
(
   caipu_id             varchar(20) not null,
   caipu_name           varchar(20) not null,
   caipu_yongliao       varchar(200) not null,
   step                 int not null,
   picture              longblob,
   primary key (caipu_id)
);

/*==============================================================*/
/* Table: dingdan_xiangqing                                     */
/*==============================================================*/
create table dingdan_xiangqing
(
   manzhe_id            varchar(20) not null,
   dingdan_id           varchar(20) not null,
   shangpin_id          varchar(20) not null,
   shuliang             int not null,
   jiage                float not null,
   zhekou               float,
   primary key (manzhe_id, dingdan_id, shangpin_id)
);

/*==============================================================*/
/* Table: guanliyuanxinxi                                       */
/*==============================================================*/
create table guanliyuanxinxi
(
   yuangong_id          varchar(20) not null,
   yuangong_name        varchar(20) not null,
   demglumima           varchar(20) not null,
   primary key (yuangong_id)
);

/*==============================================================*/
/* Table: leibie                                                */
/*==============================================================*/
create table leibie
(
   leibie_id            varchar(20) not null,
   shangpin_id          varchar(20) not null,
   primary key (leibie_id, shangpin_id)
);

/*==============================================================*/
/* Table: manzhe_shangpin_guanlian                              */
/*==============================================================*/
create table manzhe_shangpin_guanlian
(
   shangpin_id          varchar(20) not null,
   manzhe_id            varchar(20) not null,
   start_date           datetime not null,
   end_date             datetime not null,
   primary key (shangpin_id, manzhe_id)
);

/*==============================================================*/
/* Table: manzhe_xinxi                                          */
/*==============================================================*/
create table manzhe_xinxi
(
   manzhe_id            varchar(20) not null,
   neirong              varchar(200) not null,
   shangping_number     int not null,
   zhekou               float not null,
   start_date           datetime not null,
   end_date             datetime not null,
   primary key (manzhe_id)
);

/*==============================================================*/
/* Table: peisong_dizhi                                         */
/*==============================================================*/
create table peisong_dizhi
(
   dizhi_id             varchar(20) not null,
   yonghu_id            varchar(20),
   sheng                varchar(10) not null,
   shi                  varchar(10) not null,
   qu                   varchar(10) not null,
   dizhi                varchar(20) not null,
   lianxiren            varchar(20) not null,
   phonenumber          varchar(20) not null,
   primary key (dizhi_id)
);

/*==============================================================*/
/* Table: shangpin                                              */
/*==============================================================*/
create table shangpin
(
   shangpin_id          varchar(20) not null,
   shangpin_name        varchar(20) not null,
   price                float not null,
   VIP_price            float,
   number               bigint not null,
   guige                varchar(20),
   xiangqing            varchar(100),
   primary key (shangpin_id)
);

/*==============================================================*/
/* Table: shangpin_caipu_tuijian                                */
/*==============================================================*/
create table shangpin_caipu_tuijian
(
   shangpin_id          varchar(20) not null,
   caipu_id             varchar(20) not null,
   describle            varchar(200),
   primary key (shangpin_id, caipu_id)
);

/*==============================================================*/
/* Table: shangpin_pinjia                                       */
/*==============================================================*/
create table shangpin_pinjia
(
   shangpin_id          varchar(20) not null,
   yonghu_id            varchar(20) not null,
   pingjianeirong       varchar(200),
   pingjia_date         datetime not null,
   star_rating          int not null,
   ��Ƭ                   longblob,
   primary key (shangpin_id, yonghu_id)
);

/*==============================================================*/
/* Table: shangpincaigou                                        */
/*==============================================================*/
create table shangpincaigou
(
   yuangong_id          varchar(20),
   shangpin_id          varchar(20),
   caigoudan_id         varchar(20),
   number               bigint,
   xiadan               bool,
   zaitu                bool,
   rukku                bool
);

/*==============================================================*/
/* Table: shangpindingdan                                       */
/*==============================================================*/
create table shangpindingdan
(
   dingdan_id           varchar(20) not null,
   card_id              varchar(20),
   dizhi_id             varchar(20) not null,
   yonghu_id            varchar(20),
   yuanshi_money        float not null,
   jiesuan_money        float not null,
   songda_date          datetime not null,
   xiadan               bool,
   peisong              bool,
   songda               bool,
   tuihuo               bool,
   primary key (dingdan_id)
);

/*==============================================================*/
/* Table: shenxian_leibie1                                      */
/*==============================================================*/
create table shenxian_leibie1
(
   leibie_id            varchar(20) not null,
   leibie_name          varchar(20) not null,
   leibie_miaoshu       varchar(100),
   primary key (leibie_id)
);

/*==============================================================*/
/* Table: xianshicuxiao                                         */
/*==============================================================*/
create table xianshicuxiao
(
   cuxiao_id            varchar(20) not null,
   shangpin_id          varchar(20),
   cixiao_price         float not null,
   cuxiao_number        int not null,
   start_date           timestamp not null,
   end_date             timestamp not null,
   primary key (cuxiao_id)
);

/*==============================================================*/
/* Table: yonghuxinxi                                           */
/*==============================================================*/
create table yonghuxinxi
(
   yonghu_id            varchar(20) not null,
   name                 varchar(20) not null,
   sex                  varchar(5) not null,
   mima                 varchar(20) not null,
   phonenumber          varchar(20) not null,
   mail                 varchar(30),
   suozaicity           varchar(20) not null,
   zhuce_date           datetime not null,
   VIP                  bool not null,
   VIP_end_date         datetime not null,
   primary key (yonghu_id)
);

/*==============================================================*/
/* Table: youhuicard                                            */
/*==============================================================*/
create table youhuicard
(
   card_id              varchar(20) not null,
   card_neirong         varchar(200) not null,
   price_fanwei         float not null,
   reduce               float not null,
   start_date           datetime not null,
   end_date             datetime not null,
   primary key (card_id)
);

alter table dingdan_xiangqing add constraint FK_dingdan_xiangqing foreign key (manzhe_id)
      references manzhe_xinxi (manzhe_id) on delete restrict on update restrict;

alter table dingdan_xiangqing add constraint FK_dingdan_xiangqing2 foreign key (dingdan_id)
      references shangpindingdan (dingdan_id) on delete restrict on update restrict;

alter table dingdan_xiangqing add constraint FK_dingdan_xiangqing3 foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table leibie add constraint FK_leibie foreign key (leibie_id)
      references shenxian_leibie1 (leibie_id) on delete restrict on update restrict;

alter table leibie add constraint FK_leibie2 foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table manzhe_shangpin_guanlian add constraint FK_manzhe_shangpin_guanlian foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table manzhe_shangpin_guanlian add constraint FK_manzhe_shangpin_guanlian2 foreign key (manzhe_id)
      references manzhe_xinxi (manzhe_id) on delete restrict on update restrict;

alter table peisong_dizhi add constraint FK_house foreign key (yonghu_id)
      references yonghuxinxi (yonghu_id) on delete restrict on update restrict;

alter table shangpin_caipu_tuijian add constraint FK_shangpin_caipu_tuijian foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table shangpin_caipu_tuijian add constraint FK_shangpin_caipu_tuijian2 foreign key (caipu_id)
      references caipu (caipu_id) on delete restrict on update restrict;

alter table shangpin_pinjia add constraint FK_shangpin_pinjia foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table shangpin_pinjia add constraint FK_shangpin_pinjia2 foreign key (yonghu_id)
      references yonghuxinxi (yonghu_id) on delete restrict on update restrict;

alter table shangpincaigou add constraint FK_caigou foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

alter table shangpincaigou add constraint FK_control foreign key (yuangong_id)
      references guanliyuanxinxi (yuangong_id) on delete restrict on update restrict;

alter table shangpindingdan add constraint FK_have_order foreign key (yonghu_id)
      references yonghuxinxi (yonghu_id) on delete restrict on update restrict;

alter table shangpindingdan add constraint FK_mudidi foreign key (dizhi_id)
      references peisong_dizhi (dizhi_id) on delete restrict on update restrict;

alter table shangpindingdan add constraint FK_use foreign key (card_id)
      references youhuicard (card_id) on delete restrict on update restrict;

alter table xianshicuxiao add constraint FK_cuxiao_shangpin foreign key (shangpin_id)
      references shangpin (shangpin_id) on delete restrict on update restrict;

